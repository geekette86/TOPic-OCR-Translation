/** Automatically generated file. DO NOT MODIFY */
package com.android.pfe;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}